EDID Grabber for EDID.tv

This program will collect EDID data from Windows Registry and upload them to EDID.tv

Visit EDID.tv for more details.